insert  into  persona  (nombre,  ape_paterno,  email)  values  ('Admin',  'admin', 'admin@icursos.net');
insert  into  persona  (nombre,  ape_paterno,  email)  values  ('Juan',  'Perez', 'juan@gmail.com');
insert  into  persona  (nombre,  ape_paterno,  email)  values  ('Juan', 'Rodriguez', 'jrodriguez@gmail.com');